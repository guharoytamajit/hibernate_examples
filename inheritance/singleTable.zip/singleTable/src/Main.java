import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;


public class Main {


	public static void main(String[] args) {
		
		Project p=new Project();
		p.setProjectName("project1");
		
		Module m=new Module();
		m.setProjectName("project2");
		m.setModuleName("module2");
		
		Task t=new Task();
		t.setProjectName("project3");
		t.setModuleName("module3");
		t.setTaskName("task3");
		
		
SessionFactory factory = new Configuration().configure().buildSessionFactory();
Session session = factory.openSession();
session.beginTransaction();

session.save(p);
session.save(m);
session.save(t);

session.getTransaction().commit();
session.close();

	}

}
