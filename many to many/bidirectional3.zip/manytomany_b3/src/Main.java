import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;


public class Main {
public static void main(String[] args) {
	Student s1=new Student();
	s1.setName("alex");
	s1.setRoll(2);
	Student s2=new Student();
	s2.setName("joe");
	s2.setRoll(3);
	
 Course c1=new Course();
 c1.setCid("ph");
 c1.setCname("phy");
 Course c2=new Course();
 c2.setCid("ch");
 c2.setCname("chem");
 
 s1.getCourses().add(c1);
 s1.getCourses().add(c2);
 s2.getCourses().add(c1);
 
c1.getStudents().add(s1);
c1.getStudents().add(s2);
c2.getStudents().add(s1);
 
	
	SessionFactory factory = new Configuration().configure().buildSessionFactory();
	Session session = factory.openSession();
	session.beginTransaction();
	session.save(s1);
	session.save(s2);
	session.save(c1);
	session.save(c2);
	session.getTransaction().commit();
	session.close();
	
}
}
