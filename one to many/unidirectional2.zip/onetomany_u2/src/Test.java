import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		Vehicle v1 = new Vehicle(876435654, "audi", "silver");
		Vehicle v2 = new Vehicle(126435654, "enzo", "red");
		Vehicle v3 = new Vehicle(456435654, "bugetti-veyron", "blue");

		User u1 = new User("tamojit", 29);
		u1.getVehicles().add(v1);
		u1.getVehicles().add(v2);
		u1.getVehicles().add(v3);

		SessionFactory factory = new Configuration().configure()
				.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();

		session.saveOrUpdate(u1);
		session.saveOrUpdate(v1);
		session.saveOrUpdate(v2);
		session.saveOrUpdate(v3);

		session.getTransaction().commit();
		session.close();
	}
}
