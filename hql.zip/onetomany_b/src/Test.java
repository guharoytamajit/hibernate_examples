import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {


		SessionFactory factory = new Configuration().configure()
				.buildSessionFactory();
		Session session = factory.openSession();
		session.beginTransaction();
//wrong// String query="select u.name from User u where u.vehicles.model='enzo'";//org.hibernate.QueryException: illegal attempt to dereference collection 
//ok	//String query="select v.user.age from Vehicle v where v.model='enzo'";
//ok	//String query="select u.age from Vehicle v inner join v.user u where v.model='enzo'";
//ok	//String query="select u.age from User u inner join u.vehicles v where v.model='enzo'";
//ok    //String query="select u.age from User u where u=(select v.user from Vehicle v where v.model='enzo')";
//ok    //String query="select u.age from User u where u.name=(select v.user.name from Vehicle v where v.model='enzo')";
String query="select u.age from User u,Vehicle v where v.user.name=u.name and v.model='enzo'";
		
		Query q = session.createQuery(query);
 List<Integer> age=(List<Integer>)q.list();
 System.out.println(age.get(0));
		session.getTransaction().commit();
		session.close();
	}
}
