import java.io.File;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class User {
	@Id
String name;
int age;
File photo;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public User(String name, int age, File photo) {
	super();
	this.name = name;
	this.age = age;
	this.photo = photo;
}
public User() {
	super();
}
@Override
public String toString() {
	return "User [name=" + name + ", age=" + age + ", photo=" + photo + "]";
}
public File getPhoto() {
	return photo;
}
public void setPhoto(File photo) {
	this.photo = photo;
} 


}
