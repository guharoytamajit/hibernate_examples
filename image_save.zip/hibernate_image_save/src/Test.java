import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


public class Test {
public static void main(String[] args) throws IOException {

//	User u1=new User("tamojit", 28,new File("F:\\Documents and Settings\\Administrator\\My Documents\\Downloads\\fire_smiley.png"));
//	
	SessionFactory factory=new Configuration().configure().buildSessionFactory();
	Session session=factory.openSession();
//	session.beginTransaction();
//	session.saveOrUpdate(u1);
//	session.getTransaction().commit();
//	session.close();
	
	session=factory.openSession();
	session.beginTransaction();
	Query q = session.createQuery("select u.photo from User u where u.age=28");
	List<File> photo = (List<File>)q.list();
	FileInputStream fis=new FileInputStream(photo.get(0));
	FileOutputStream fos=new FileOutputStream("c:/sun.png");
	int i=0;
	byte[] buffer=new byte[100];
	while((i=fis.read(buffer))>0){
		fos.write(buffer);
	}
	fos.flush();
	fos.close();
	fis.close();
	session.getTransaction().commit();
	session.close();
}
}
